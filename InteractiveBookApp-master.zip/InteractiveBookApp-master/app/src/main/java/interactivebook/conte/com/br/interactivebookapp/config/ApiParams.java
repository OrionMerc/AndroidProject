package interactivebook.conte.com.br.interactivebookapp.config;

public class ApiParams {

    private static final String URL = "http://interactivebookapi.herokuapp.com/";

    public static String getURL(){
        return URL;
    }
}
